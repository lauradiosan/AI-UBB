var students = [{hours:1.50, sleep:4, passed:0},{hours:1.75, sleep:5, passed:0},{hours:1.75, sleep:4, passed:1},{hours:2.0, sleep:5, passed:0},{hours:2.25, sleep:3, passed:0},{hours:2.50, sleep:4.5, passed:0},
{hours:2.75, sleep:8, passed:1},{hours:3.0, sleep:3.5, passed:0},{hours:0.50, sleep:2, passed:0},{hours:0.75, sleep:4.5, passed:0},{hours:1.0, sleep:2, passed:0},{hours:1.25, sleep:3, passed:0},
{hours:3.25, sleep:7.5, passed:1},{hours:3.50, sleep:2.5, passed:0},{hours:4.0, sleep:7.5, passed:1},
{hours:4.25, sleep:7, passed:1},{hours:4.50, sleep:6, passed:1},{hours:4.75, sleep:8, passed:1},{hours:5.0, sleep:7.5, passed:1},{hours:5.50, sleep:8, passed:1}]
var newData = [];

function setup() {
  createCanvas(400, 400);
  
  train(4000,0.01);
}

function draw() {
 
  background(51);
  // Draw data to predict
  if (newData.length > 1) {
    for (var j = 0; j < newData.length; j++) {
      var x = map(newData[j].hours, 0, 6, 0, width);
      var y = map(newData[j].sleep, 0, 12, height, 0);
      
      var res = predict(newData[j].hours, newData[j].sleep);
      
      if (res == 1) {
        fill('blue');
        stroke('blue');
        ellipse(x, y, 12, 12);
      } else {
        fill('red');
        stroke('red');
        ellipse(x, y, 12, 12);
      }
    }
  }
  
  //Draw Students
  if (students.length > 1) {
    for (var j = 0; j < students.length; j++) {
      var x = map(students[j].hours, 0, 6, 0, width);
      var y = map(students[j].sleep, 0, 12, height, 0);
      var z = students[j].passed;
   
      if (z == 1) {
        fill('blue');
        stroke('blue');
        ellipse(x, y, 8, 8);
      } else {
        fill('red');
        stroke('red');
        ellipse(x, y, 8, 8);
      }
    }
  }
}

var B1,B2,B0;

function train(epochs, learningRate){
    errors =[];
    B1 = 0.0;
    B0 = 0.0;
    B2 = 0.0;

    for (var i=0; i<epochs; i++){

        students.forEach(d=>{
            func = (B1*d.hours)+(B2*d.sleep)+B0;
            predY = 1/(1+Math.exp(-func))
            
            var error = predY - d.passed;
            
            print('Predictia: ',predY);
            print('Error: ',error);

            B1 = B1 - (error * d.hours * learningRate);
            B2 = B2 - (error * d.sleep * learningRate);
            B0 = B0 - error * learningRate;
         })

        print('BO:',B0);
        print('B1:',B1);
        print('B2:',B2);
    }
}

function mousePressed() {
  var x = map(mouseX, 0, width, 0, 6);
  var y = map(mouseY, 0, height, 12, 0);
  
  print('Hours: ',x);
  print('Sleep: ',y);
  
  print(predict(x,y));
  
  newData.push({hours:x, sleep:y, passed:0});
}

function predict(x,y){
    var predY;
    var func;
    var out;
    func = (B1*x)+(B2*y)+B0;
    predY = 1/(1+Math.exp(-func));
   
    if (predY > 0.5){
      out=1
    } else {
      out=0
    };
   
    return out;
}
